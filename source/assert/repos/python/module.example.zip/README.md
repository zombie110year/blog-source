# 目录结构

```
main/
|   echo.py
|       doc
|       def hello()
|       class Echor()
|           def echo()
|
|   echo_imported.py
|       doc
|       def hello()
|       class Echor()
|           def echo()
|
|   __init__.py
|       from . import echo_imported
|       def hello()
|       def main()
|       class Test()
|
|---subdir/
|       test.py
|           doc
|           def check()
|
\---invalidir/
        test.py
            doc
            def check()
```