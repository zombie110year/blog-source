#! /usr/bin/env python3
# -*- coding: utf-8 -*-

doc = """\
这是 /main/subdir/test.py
"""

def check():
    print("/main/subdir/test.py 中的 check 函数")

check()