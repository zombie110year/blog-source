#! /usr/bin/env python3
# -*- coding: utf-8 -*-

__doc__ = """\
这里是 main 目录下的 echo_imported.py 文件
"""

def hello():
    print("你好,%s"%__doc__)
    return

class Echor(object):
    """这是 /main/echo_imported.py 中的 Echor 类"""
    def __init__(self):
        self.name = "Echor"

hello()