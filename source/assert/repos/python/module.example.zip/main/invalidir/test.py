#! /usr/bin/env python3
# -*- coding: utf-8 -*-

doc = """\
这里是 /main/invalidir/test.py, 这个目录没有 __init__.py
"""

def check():
    print("/main/invalid/test.py 中的 check 函数")

check()