#! /usr/bin/env python3
# -*- coding: utf-8 -*-

from . import echo_imported

def hello():
    print("你好! 这里是 main 目录下的__init__.py")
    return

def main():
    print("你直接运行 Python __init__.py 了吧")

class Test(object):
    """这是在 main 目录下的 __init__.py 中定义的类"""
    def __init__(self):
        print(Test.__doc__)

if __name__ == "__main__":
    main()

hello()