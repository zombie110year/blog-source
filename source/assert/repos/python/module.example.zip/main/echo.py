#! /usr/bin/env python3
# -*- coding: utf-8 -*-

doc = """\
这里是 main 目录下的 echo.py 文件
"""

def hello():
    print("你好,%s"%doc)
    return

class Echor(object):
    """这是 /main/echo.py 中的 Echor 类"""
    def __init__(self):
        self.name = "Echor"
    def echo(self):
        print("这里是 /main/echo.py:class Echor():def echo()")

hello()